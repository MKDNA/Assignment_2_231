$(document).ready(function() {
    $('#feedbackForm').submit(function(event) {
      event.preventDefault(); // Prevent form submission
  
      var name = $('#name').val();
      var email = $('#email').val();
      var contact = $('#contact').val();
      var feedback = $('#feedback').val();
  
      // Validate form inputs
      if (name === '' || email === '' || feedback === ''|| contact === '') {
        alert('Please fill in all fields');
        return;
      }
  
      // Send feedback data to server (simulate with console.log here)
      console.log('Name: ' + name);
      console.log('Email: ' + email);
      console.log('Contact: ' + contact);
      console.log('Feedback: ' + feedback);
  
      // Reset form
      $('#feedbackForm')[0].reset();
    });
  });
  